+===================================+
| WooCommerce JNE Shipping ( Free Version ) |
+===================================+
Developer : Fairuz Fatin
Author URL : http://www.agenwebsite.com/
Plugin URL : http://http://shop.agenwebsite.com/products/woocommerce-jne-shipping/

Plugin untuk WooCommerce dengan penambahan metode shipping JNE.

+===================================+
| Installation |
+===================================+
1. Unzip files.
2. Upload "woocommerce-jne" folder into your plugins directory.
3. Activate the plugin.
4. Go to WooCommerce > Settings > Shipping > JNE Shipping.
5. Configure settings to your needs.
6. Have fun!

+===================================+
| Change Log |
+===================================+
Version 7.0.2
- Perbaikan bug pembelian kedua shipping tidak muncul
- Perbaikan bug Shipping Calculator
- Perbaikan layout di Theme Mindig

Version 7.0.1
- Perbaikan bug layanan jne
- Perbaikan bug select2 dan chosen

Version 7.0.0
- Kompatibel dengan WooCommerce versi 2.2.11
- Update interface admin terbaru
- Update interface free shipping
- Fitur reorder layanan
- Fitur extra cost per layanan

Version 5.0.4
- Perbaikan chosen di checkout

Version 5.0.3
- Perbaikan tanpa chosen plugin dapat bekerja dengan baik

Version 5.0.2
- Perbaikan bug checkout

Version 5.0.1
- Perbaikan halaman setting jne di woocommerce versi 2.0.x

Version 5.0.0
- Perubahan sistem jne shipping
- Penambahan javascript dan css
- 

Version 4.1.0
- Perbakan beberapa bug
- Perubahan tampilan admin
- Perubahan list kota dari provinsi menjadi kota

Version 4.0.1
- Perbaikan beberapa bug dan error
- Perubahan tampilan admin

Version 4.0.0
- Perbaikan beberapa bug dan error
- Update penyederhanaan WooCommerce JNE Shipping
- Penambahan fitur default weight
- Perubahan format data menjadi KOTA,HARGA_OKE,HARGA_REG,HARGA_YES
- Penambahan fitur otomatis ongkos kirim ( Limited Version )
- Penambahan fitur JNE Tracking ( Limited Version )
- Pengembalian fitur Kode Pos 

Version 3.0.1
- Update harga JNE Jakarta 2013

Version 3.0.0
- Perbaikan fitur asuransi
- Perubahan style list data
- Penambahan edit data
- Penghapusan Textarea data
- Penghapusan negara yang diizinkan
Version 2.0.0
- Penambahan support WooCommerce versi 2.0.1
- Perbaikan beberapa bug dan error
- Penambahan fitur asuransi
- Penambahan fitur check update
- Penambahan berapa banyak kota

Version 1.0.2
- Penambahan fitur Import City by Text
- Mudah untuk mengedit kembali dari Text Area yang sudah ada
- Perubahan link credits

Version 1.0.1
- Updated Opsi JNE REG/OKE/JNE *Premium Version
- Pilihan Negara yang diizinkan
- Penambahan fungsi jika kota kosong maka opsi jasa pengiriman tidak ada dan tidak bisa mengirim barang
- Pembetulan fungsi - fungsi yang error
- Penambahan Link Video Tutorial

Version 1.0.0
- Product Launching
